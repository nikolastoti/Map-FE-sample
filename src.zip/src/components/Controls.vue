<template>
  <div class="controls">
    <a href="https://www.kpler.com/" target="_blank">
      <img id="logo" src="../../public/logo.png" />
    </a>
    <input
      v-model="search"
      type="text"
      class="search-input"
      placeholder="Search countries"
    />
    <button @click="toggleSortOrderName">
      <span v-if="isAscendingName">↑</span>
      <span v-else-if="isAscendingName === false">↓</span>
      Sort by Name
    </button>
    <button @click="toggleSortOrderPopulation">
      <span v-if="isAscendingPopulation">↑</span>
      <span v-else-if="isAscendingPopulation === false">↓</span>
      Sort by Population
    </button>
    <div class="average-population">
      Average Population: {{ calculateAveragePopulation(filteredCountries) }}
    </div>
  </div>
</template>

<script>
export default {
  props: {
    filteredCountries: {
      type: Array,
      required: true,
    },
  },
  data() {
    return {
      search: "",
      isAscendingName: undefined,
      isAscendingPopulation: undefined,
    };
  },
  methods: {
    toggleSortOrderName() {
      this.isAscendingName = !this.isAscendingName;
      this.$emit("sort-name", this.isAscendingName);
    },
    toggleSortOrderPopulation() {
      this.isAscendingPopulation = !this.isAscendingPopulation;
      this.$emit("sort-population", this.isAscendingPopulation);
    },
    calculateAveragePopulation(countries) {
      if (countries.length === 0) return 0;
      const totalPopulation = countries.reduce(
        (acc, country) => acc + country.population,
        0
      );
      let averagePopulation = Math.round(totalPopulation / countries.length);
      averagePopulation = averagePopulation.toLocaleString();
      return averagePopulation;
    },
  },
  watch: {
    search(newSearch) {
      this.$emit("search-updated", newSearch);
    },
  },
};
</script>
