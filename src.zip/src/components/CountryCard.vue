<template>
  <div class="card">
    <h2 class="name">{{ country.flag }}&nbsp;{{ country.name.common }}</h2>
    <p class="capital" v-if="country.capital">
      Capital: {{ country.capital?.[0] }}
    </p>
    <p class="population">Population: {{ country.population }}</p>
    <p class="borders" v-if="formattedBorders">
      Borders: {{ formattedBorders }}
    </p>
    <button @click="focusMapOnThisCountry" class="focusBtn">Focus</button>
  </div>
</template>

<script>
import { EventBus } from "../assets/eventBus";
export default {
  props: {
    country: {
      type: Object,
      required: true,
    },
    allCountries: {
      type: Array,
      required: true,
    },
  },
  computed: {
    formattedBorders() {
      return this.country.borders
        ?.map((abbreviation) => this.countryAbbreviationMapping[abbreviation])
        .join(", ");
    },
    countryAbbreviationMapping() {
      return this.allCountries.reduce((mapping, country) => {
        mapping[country.cca3] = country.name.common;
        return mapping;
      }, {});
    },
  },
  methods: {
    focusMapOnThisCountry() {
      EventBus.$emit("focus-country", this.country);
    },
  },
};
</script>
