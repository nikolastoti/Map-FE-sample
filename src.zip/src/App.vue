<template>
  <div id="app">
    <div class="controls">
      <Controls
        @search-updated="updateSearch"
        @sort-name="sortCountriesByName"
        @sort-population="sortCountriesByPopulation"
        :filteredCountries="filteredCountries"
      />
    </div>
    <CountryList
      :countries="filteredCountries"
      @update:countries="updateCountries"
    />
    <Map :countries="filteredCountries" />
  </div>
</template>

<script>
import Controls from "./components/Controls";
import CountryList from "./components/CountryList";
import Map from "./components/Map";
import "./assets/style.css";

export default {
  name: "App",
  components: {
    Controls,
    CountryList,
    Map,
  },
  data() {
    return {
      countries: [],
      allCountries: [],
      search: "",
    };
  },
  computed: {
    filteredCountries() {
      const filtered = this.countries.filter((country) =>
        country.name.common.toLowerCase().includes(this.search.toLowerCase())
      );

      this.$emit("update:countries", filtered);

      return filtered;
    },
  },
  methods: {
    updateSearch(newSearch) {
      this.search = newSearch;
    },
    updateCountries({ filtered, all }) {
      this.countries = filtered;
      this.allCountries = all;
    },
    sortCountriesByName(isAscendingName) {
      if (isAscendingName) {
        this.countries.sort((a, b) =>
          a.name.common.localeCompare(b.name.common)
        );
      } else {
        this.countries.sort((a, b) =>
          b.name.common.localeCompare(a.name.common)
        );
      }
    },
    sortCountriesByPopulation(isAscendingPopulation) {
      if (isAscendingPopulation) {
        this.countries.sort((a, b) => a.population - b.population);
      } else {
        this.countries.sort((a, b) => b.population - a.population);
      }
    },
  },
};
</script>
